def hello(event, context):
    print("Hei Folkens!")


if __name__ == "__main__":
    hello()
